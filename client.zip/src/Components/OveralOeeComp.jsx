// @flow

import React from 'react';

function OveralOeeComp(props) {
    return (
        <div>
            test
        </div>
    );
}

export default OveralOeeComp;