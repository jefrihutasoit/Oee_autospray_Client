

function Mini_chart(){
    return (
    <div>
            <div style={{display:'flex'}}>
            <div className=""></div>
            <div></div>
            <div></div>
            </div>
    </div>
    )
}

export default Mini_chart